#include "stdio.h"

void generate(char*, int, size_t);
void sort_lib(char*, int, size_t);
void sort_sys(char*, int, size_t);
void copy_lib(char*, char*, int, size_t);
void copy_sys(char*, char*, int, size_t);